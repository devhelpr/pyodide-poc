"""The :mod:`unsupervised_bias_detection.clustering` module implements bias-aware clustering algorithms."""

from ._kmeans import BiasAwareHierarchicalKMeans

__all__ = [
    "BiasAwareHierarchicalKMeans"
]
